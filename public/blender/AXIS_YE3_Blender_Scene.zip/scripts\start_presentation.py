"""Presentation startup for the AXIS motor scene.

Blender's saved viewport shading type is not reliably restored when a .blend is
opened, so this script runs inside the GUI and switches every 3D view to a
clean rendered camera view. It does not modify or save the .blend.

Launch through OPEN_MOTOR_SCENE.bat or the desktop shortcut.
"""
import bpy


def set_presentation_view():
    scene = bpy.context.scene
    try:
        scene.frame_set(1)
    except Exception:
        pass
    count = 0
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type != 'VIEW_3D':
                continue
            for space in area.spaces:
                if space.type != 'VIEW_3D':
                    continue
                try:
                    space.shading.type = 'RENDERED'
                    space.shading.use_scene_lights = True
                    space.shading.use_scene_world = True
                except Exception:
                    pass
                try:
                    space.region_3d.view_perspective = 'CAMERA'
                except Exception:
                    pass
                try:
                    space.overlay.show_overlays = False
                except Exception:
                    pass
                count += 1
    print('AXIS_PRESENTATION_VIEW_READY', count)
    try:
        bpy.app.timers.unregister(set_presentation_view)
    except Exception:
        pass


bpy.app.timers.register(set_presentation_view, first_interval=0.8)

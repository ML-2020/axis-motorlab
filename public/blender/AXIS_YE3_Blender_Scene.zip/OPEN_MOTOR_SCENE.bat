@echo off
setlocal
cd /d "%~dp0"
set "BLENDER=C:\Program Files\Blender Foundation\Blender 4.2\blender.exe"
if not exist "%BLENDER%" set "BLENDER=blender"
start "" "%BLENDER%" "AXIS_YE3_132S_Motor.blend" --python "scripts\start_presentation.py"

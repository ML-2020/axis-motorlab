from PIL import Image, ImageDraw, ImageFont, ImageFilter
import math, random, os
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS = os.path.join(BASE, "assets")
os.makedirs(ASSETS, exist_ok=True)
random.seed(17)

def font(size, bold=False):
    paths = [
        r"C:\Windows\Fonts\arialbd.ttf" if bold else r"C:\Windows\Fonts\arial.ttf",
        r"C:\Windows\Fonts\seguisb.ttf",
        r"C:\Windows\Fonts\segoeui.ttf",
    ]
    for p in paths:
        if os.path.exists(p):
            try: return ImageFont.truetype(p, size)
            except Exception: pass
    return ImageFont.load_default()

def font_cn(size, bold=True):
    paths = [
        r"C:\Windows\Fonts\msyhbd.ttc" if bold else r"C:\Windows\Fonts\msyh.ttc",
        r"C:\Windows\Fonts\msyh.ttc",
        r"C:\Windows\Fonts\simhei.ttf",
    ]
    for p in paths:
        if os.path.exists(p):
            try: return ImageFont.truetype(p, size)
            except Exception: pass
    return font(size, bold)

def brushed(w, h):
    im = Image.new("RGB", (w, h))
    px = im.load()
    for y in range(h):
        base = 175 + 35 * math.sin(y * 0.028) + random.uniform(-14, 18)
        for x in range(w):
            v = base + random.uniform(-10, 10) + 8 * math.sin(x * 0.01 + y * .04)
            px[x, y] = (int(v), int(v + 3), int(v + 5))
    return im

def nameplate():
    w, h = 1024, 640
    im = brushed(w, h)
    d = ImageDraw.Draw(im)
    d.rectangle([18, 18, w-18, h-18], outline=(48, 58, 61), width=9)
    d.rectangle([32, 32, w-32, h-32], outline=(95, 105, 106), width=2)
    ink = (20, 30, 33)
    d.text((60, 58), "AXIS", font=font(48, True), fill=ink)
    d.text((196, 73), "MOTORLAB", font=font(27), fill=(58, 68, 70))
    d.text((60, 112), "THREE-PHASE INDUCTION MOTOR", font=font(25), fill=(67, 77, 79))
    d.text((58, 168), "YE3-132S-4", font=font(86, True), fill=(15, 23, 25))
    d.text((60, 276), "5.5 kW      380 V      50 Hz      11.4 A", font=font(29, True), fill=(42, 53, 56))
    d.text((60, 321), "1440 r/min     cosφ 0.83     η 89.6 %", font=font(29, True), fill=(42, 53, 56))
    d.text((60, 366), "IP55   IC411   IM B3   S1   IE3", font=font(27), fill=(28, 39, 42))
    d.line([60, 408, w-60, 408], fill=(110, 120, 120), width=2)
    d.text((60, 431), "IEC 60034-1  /  GB/T 28575-2020", font=font(20), fill=(81, 92, 93))
    d.text((60, 463), "SERIAL  AX3-132S-0550-0091", font=font(20), fill=(81, 92, 93))
    d.text((60, 495), "MFG  AXIS ELECTRIC WORKS   ·   2026", font=font(20), fill=(81, 92, 93))
    # stamp / QR-like block
    d.text((747, 418), "IE3 · PREMIUM", font=font(20, True), fill=(48, 59, 61))
    d.text((747, 443), "EFFICIENCY", font=font(20, True), fill=(48, 59, 61))
    d.rectangle([750, 470, 872, 592], fill=(28, 38, 40))
    for y in range(8):
        for x in range(8):
            if (x * 5 + y * 3 + x * y) % 3 == 0:
                d.rectangle([760+x*13, 480+y*13, 769+x*13, 489+y*13], fill=(215, 220, 216))
    # rivets
    for (x,y) in [(48,48),(w-48,48),(48,h-48),(w-48,h-48)]:
        for r, c in [(12, (50,60,62)),(9,(145,152,152)),(5,(224,228,225))]:
            d.ellipse([x-r,y-r,x+r,y+r], fill=c)
    im = im.filter(ImageFilter.GaussianBlur(0.35))
    im.save(os.path.join(ASSETS, "nameplate.png"))

def warning():
    w, h = 512, 256
    im = Image.new("RGB", (w, h), (16, 20, 21))
    d = ImageDraw.Draw(im)
    d.rectangle([6,6,w-6,h-6], fill=(27, 31, 30), outline=(200, 134, 39), width=5)
    d.rectangle([20,20,w-20,h-20], outline=(200, 134, 39), width=2)
    d.polygon([(52, 58), (88, 126), (16, 126)], fill=(224, 161, 58))
    d.text((41, 82), "!", font=font(44, True), fill=(17, 20, 20))
    d.text((105, 48), "WARNING", font=font(34, True), fill=(232, 177, 83))
    d.text((105, 88), "HIGH VOLTAGE", font=font(22, True), fill=(215, 216, 205))
    d.text((26, 148), "DISCONNECT POWER BEFORE SERVICE", font=font(19), fill=(154, 165, 163))
    d.text((26, 182), "危险电压  ·  断电后检修", font=font_cn(25, True), fill=(232, 177, 83))
    d.text((26, 218), "IP55  ·  IE3  ·  AXIS MOTORLAB", font=font(14), fill=(104, 118, 117))
    im.save(os.path.join(ASSETS, "warning.png"))

def brand_plate():
    w, h = 512, 160
    im = Image.new("RGB", (w, h), (20, 35, 39))
    d = ImageDraw.Draw(im)
    d.rectangle([9,9,w-9,h-9], outline=(115, 150, 153), width=2)
    d.text((28, 34), "AXIS", font=font(56, True), fill=(222, 225, 220))
    d.rectangle([170, 39, 174, 103], fill=(218, 151, 48))
    d.text((193, 55), "MOTORLAB", font=font(29, True), fill=(160, 180, 180))
    d.text((30, 114), "SERIES YE3  ·  IE3", font=font(19), fill=(120, 140, 140))
    im.save(os.path.join(ASSETS, "brand.png"))

nameplate(); warning(); brand_plate()
print("TEXTURES_OK", ASSETS)

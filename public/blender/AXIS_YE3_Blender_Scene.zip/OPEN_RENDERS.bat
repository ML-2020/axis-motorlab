@echo off
start "" "%~dp0renders"

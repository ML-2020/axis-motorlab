@echo off
setlocal
cd /d "%~dp0"
set "BLENDER=C:\Program Files\Blender Foundation\Blender 4.2\blender.exe"
if not exist "%BLENDER%" set "BLENDER=blender"
echo Rendering the 7.5 second exploded animation...
"%BLENDER%" -b "AXIS_YE3_132S_Motor.blend" --python "scripts\render_animation.py"
echo.
echo Done. Open renders\AXIS_YE3_exploded.mp4
pause

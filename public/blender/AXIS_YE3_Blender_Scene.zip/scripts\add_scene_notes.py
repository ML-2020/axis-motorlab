"""Add project metadata / a README text datablock to the saved scene."""
import bpy
import os

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BLEND = os.path.join(BASE, 'AXIS_YE3_132S_Motor.blend')
bpy.ops.wm.open_mainfile(filepath=BLEND)
scene = bpy.context.scene
scene['project'] = 'AXIS MOTORLAB'
scene['asset'] = 'YE3-132S-4 three-phase induction motor'
scene['component_count'] = 22
scene['duration_seconds'] = 7.5
scene['notes'] = 'Independent Blender scene generated with bpy. Engineering visualization, not a manufacturing drawing.'
scene.frame_set(1)
text = bpy.data.texts.get('README_AXIS_MOTORLAB') or bpy.data.texts.new('README_AXIS_MOTORLAB')
text.clear()
text.write("""AXIS MOTORLAB / YE3-132S-4
Blender 4.2 independent exploded-view scene.

22 named parts. Motor root: MOTOR_ROOT. Animation: 180 frames @ 24 fps.
Stills: renders/motor_hero.png and renders/motor_exploded.png (1920x1080).
Animation: renders/AXIS_YE3_exploded.mp4 (1600x900, 7.5 s, H.264).

Engineering visualization, not a manufacturing drawing.
Reproduce with: blender -b --factory-startup --python scripts/build_motor.py
""")
bpy.ops.wm.save_as_mainfile(filepath=BLEND)
print('METADATA_ADDED', BLEND)

"""
Render the exploded animation from the saved Blender motor scene.

Run:
  blender -b blender/AXIS_YE3_132S_Motor.blend --python blender/scripts/render_animation.py
"""
import bpy
import os
import time

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(BASE, "renders")
os.makedirs(OUT_DIR, exist_ok=True)

scene = bpy.context.scene
scene.frame_start = 1
scene.frame_end = 180
scene.render.fps = 24
scene.render.fps_base = 1.0
scene.render.resolution_x = 1600
scene.render.resolution_y = 900
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'FFMPEG'
scene.render.ffmpeg.format = 'MPEG4'
scene.render.ffmpeg.codec = 'H264'
scene.render.ffmpeg.constant_rate_factor = 'MEDIUM'
scene.render.ffmpeg.ffmpeg_preset = 'GOOD'
scene.render.ffmpeg.gopsize = 12
scene.render.ffmpeg.audio_codec = 'NONE'
scene.render.filepath = os.path.join(OUT_DIR, 'AXIS_YE3_exploded')
scene.render.use_file_extension = True
scene.eevee.taa_render_samples = 48
try:
    scene.eevee.use_raytracing = True
except Exception:
    pass
print('ANIMATION_START', time.strftime('%Y-%m-%d %H:%M:%S'))
bpy.ops.render.render(animation=True)
print('ANIMATION_DONE', time.strftime('%Y-%m-%d %H:%M:%S'))

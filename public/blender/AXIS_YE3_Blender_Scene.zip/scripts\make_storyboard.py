from PIL import Image, ImageDraw, ImageFont
import os
base = os.getcwd()
files = [os.path.join(base, "blender", "renders", "_story", f"s{i}.png") for i in range(4)]
imgs = [Image.open(p).convert("RGB") for p in files]
W, H = 1640, 1080
canvas = Image.new("RGB", (W, H), (5, 8, 9))
d = ImageDraw.Draw(canvas)
try:
    title = ImageFont.truetype(r"C:\Windows\Fonts\arialbd.ttf", 34)
    sub = ImageFont.truetype(r"C:\Windows\Fonts\arial.ttf", 17)
    cap = ImageFont.truetype(r"C:\Windows\Fonts\arialbd.ttf", 16)
except Exception:
    title = sub = cap = ImageFont.load_default()
d.text((32, 28), "AXIS MOTORLAB  /  YE3-132S-4", font=title, fill=(218, 224, 220))
d.text((34, 74), "BLENDER EXPLODED-VIEW STUDY   ·   22 COMPONENTS   ·   1600 × 900   ·   7.5 s", font=sub, fill=(111, 131, 132))
# thin accent line
d.rectangle([34, 101, 1606, 102], fill=(45, 60, 62))
labels = ["01  ASSEMBLED", "02  UNFOLDING", "03  COMPONENTS", "04  EXPLODED"]
x0, y0 = 32, 126
iw, ih = 780, 403
gap = 16
for i, im in enumerate(imgs):
    col, row = i % 2, i // 2
    x = x0 + col * (iw + gap)
    y = y0 + row * (ih + 38)
    im = im.resize((iw, ih), Image.LANCZOS)
    canvas.paste(im, (x, y))
    d.rectangle([x, y, x + iw, y + ih], outline=(31, 45, 47), width=1)
    d.text((x + 12, y + ih + 10), labels[i], font=cap, fill=(179, 196, 192))
d.text((32, 1042), "Stills rendered in EEVEE · 22 individually named parts · assembled-to-exploded camera move", font=sub, fill=(79, 98, 99))
canvas.save(os.path.join(base, "blender", "renders", "AXIS_YE3_storyboard.png"))
print("STORYBOARD_OK")

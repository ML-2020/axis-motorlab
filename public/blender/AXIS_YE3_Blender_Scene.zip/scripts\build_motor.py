"""
AXIS MOTORLAB — Blender-authored YE3-132S-4 motor scene.

Independent Blender deliverable requested by the user. All geometry is built
procedurally with bpy, so the .blend can be regenerated and edited. The scene
contains 22 named motor parts, a studio set, a product camera, an exploded
animation and published stills.

Run:
  blender -b --factory-startup --python blender/scripts/build_motor.py
"""

import bpy
import bmesh
import math
import os
import sys
import time
import random
from mathutils import Vector, Matrix

# ---------------------------------------------------------------------------
# Paths and constants
# ---------------------------------------------------------------------------
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
BLENDER_DIR = os.path.dirname(SCRIPT_DIR)
WORKSPACE = os.path.dirname(BLENDER_DIR)
ASSETS = os.path.join(BLENDER_DIR, "assets")
RENDERS = os.path.join(BLENDER_DIR, "renders")
OUT_BLEND = os.path.join(BLENDER_DIR, "AXIS_YE3_132S_Motor.blend")

os.makedirs(RENDERS, exist_ok=True)
CENTER_Z = 0.132  # shaft height above the mounting surface
TAU = math.pi * 2.0


# ---------------------------------------------------------------------------
# Scene / collection helpers
# ---------------------------------------------------------------------------
def reset_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.unit_settings.system = 'METRIC'
    scene.unit_settings.scale_length = 1.0
    scene.unit_settings.length_unit = 'MILLIMETERS'
    scene.render.engine = 'BLENDER_EEVEE_NEXT'
    scene.render.resolution_x = 1920
    scene.render.resolution_y = 1080
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = 'PNG'
    scene.render.image_settings.color_mode = 'RGBA'
    scene.render.film_transparent = False
    scene.frame_start = 1
    scene.frame_end = 180
    scene.render.fps = 24
    scene.render.fps_base = 1.0
    scene.view_settings.view_transform = 'AgX'
    try:
        scene.view_settings.look = 'AgX - Medium High Contrast'
    except Exception:
        pass
    scene.render.use_file_extension = True
    return scene


def make_collection(name, parent=None):
    coll = bpy.data.collections.new(name)
    if parent:
        parent.children.link(coll)
    else:
        bpy.context.scene.collection.children.link(coll)
    return coll


SCENE = reset_scene()
C_MOTOR = make_collection('MOTOR')
C_CTRL = make_collection('MOTOR_CONTROL')
C_STAGE = make_collection('STUDIO')
C_LIGHTS = make_collection('LIGHTING')
C_CAM = make_collection('CAMERA')


def link_to(obj, coll):
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    coll.objects.link(obj)
    return obj


def select_only(objs):
    bpy.ops.object.select_all(action='DESELECT')
    for obj in objs:
        obj.select_set(True)
    if objs:
        bpy.context.view_layer.objects.active = objs[0]


def apply_transform(obj):
    select_only([obj])
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)


def shade(obj, angle=32):
    select_only([obj])
    try:
        bpy.ops.object.shade_smooth_by_angle(angle=math.radians(angle))
    except Exception:
        try:
            bpy.ops.object.shade_smooth()
        except Exception:
            pass


def bevel(obj, width=0.0015, segments=2, angle=40):
    if width <= 0:
        return obj
    mod = obj.modifiers.new('Edge bevel', 'BEVEL')
    mod.width = width
    mod.segments = segments
    mod.limit_method = 'ANGLE'
    mod.angle_limit = math.radians(angle)
    mod.harden_normals = False
    select_only([obj])
    try:
        bpy.ops.object.modifier_apply(modifier=mod.name)
    except Exception:
        obj.modifiers.remove(mod)
    return obj


def assign(obj, mat):
    if mat and mat.name not in [m.name for m in obj.data.materials if m]:
        obj.data.materials.append(mat)
    return obj


def box(name, dims, loc=(0, 0, 0), rot=(0, 0, 0), mat=None, bev=0.0018, coll=C_MOTOR):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc, rotation=rot)
    obj = bpy.context.object
    obj.name = name
    obj.scale = dims
    apply_transform(obj)
    assign(obj, mat)
    bevel(obj, min(bev, min(dims) * 0.22), 2)
    shade(obj)
    link_to(obj, coll)
    return obj


def cyl(name, radius, depth, loc=(0, 0, 0), axis='X', mat=None, verts=64, bev=0.0008, coll=C_MOTOR, smooth=True):
    rot = (0, math.pi / 2, 0) if axis == 'X' else ((math.pi / 2, 0, 0) if axis == 'Y' else (0, 0, 0))
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=verts, radius=radius, depth=depth, end_fill_type='NGON', location=loc, rotation=rot
    )
    obj = bpy.context.object
    obj.name = name
    apply_transform(obj)
    assign(obj, mat)
    if bev:
        bevel(obj, bev, 2)
    if smooth:
        shade(obj)
    link_to(obj, coll)
    return obj


def sphere(name, radius, loc=(0, 0, 0), mat=None, coll=C_MOTOR, segments=24, rings=16):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments, ring_count=rings, radius=radius, location=loc)
    obj = bpy.context.object
    obj.name = name
    assign(obj, mat)
    shade(obj)
    link_to(obj, coll)
    return obj


def torus(name, major, minor, loc=(0, 0, 0), axis='X', mat=None, major_seg=64, minor_seg=10, coll=C_MOTOR):
    rot = (0, math.pi / 2, 0) if axis == 'X' else ((math.pi / 2, 0, 0) if axis == 'Y' else (0, 0, 0))
    bpy.ops.mesh.primitive_torus_add(
        major_radius=major, minor_radius=minor, major_segments=major_seg,
        minor_segments=minor_seg, location=loc, rotation=rot
    )
    obj = bpy.context.object
    obj.name = name
    apply_transform(obj)
    assign(obj, mat)
    shade(obj)
    link_to(obj, coll)
    return obj


def revolve_x(name, profile, mat=None, segments=96, loc=(0, 0, 0), coll=C_MOTOR, smooth_angle=32):
    """Revolve a list of (radius, x) profile points around the X axis."""
    verts = []
    n = len(profile)
    for i in range(segments):
        a = TAU * i / segments
        c, s = math.cos(a), math.sin(a)
        for r, x in profile:
            verts.append((x, r * c, r * s))
    faces = []
    for i in range(segments):
        ni = (i + 1) % segments
        for j in range(n - 1):
            a = i * n + j
            b = a + 1
            c = ni * n + j + 1
            d = ni * n + j
            faces.append((a, b, c, d))
    mesh = bpy.data.meshes.new(name + '_mesh')
    mesh.from_pydata(verts, [], faces)
    mesh.validate(verbose=False)
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=1e-6)
    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    bm.to_mesh(mesh)
    bm.free()
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    C_MOTOR.objects.link(obj)
    obj.location = loc
    assign(obj, mat)
    shade(obj, smooth_angle)
    return obj


def ring_profile(inner, outer, x0, x1):
    return [(inner, x0), (outer, x0), (outer, x1), (inner, x1), (inner, x0)]


def join_objects(objs, name, coll=C_MOTOR):
    objs = [o for o in objs if o and o.name in bpy.data.objects]
    if not objs:
        raise RuntimeError('No objects for ' + name)
    select_only(objs)
    bpy.context.view_layer.objects.active = objs[0]
    if len(objs) > 1:
        bpy.ops.object.join()
    obj = bpy.context.object
    obj.name = name
    obj.data.name = name + '_mesh'
    bpy.context.scene.cursor.location = (0, 0, 0)
    select_only([obj])
    bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
    shade(obj, 30)
    link_to(obj, coll)
    return obj


def boolean_cut(target, cutters):
    cutters = [c for c in cutters if c and c.name in bpy.data.objects]
    if not cutters:
        return target
    select_only(cutters)
    bpy.context.view_layer.objects.active = cutters[0]
    if len(cutters) > 1:
        bpy.ops.object.join()
    cutter = bpy.context.object
    cutter.name = 'BooleanCutter'
    bpy.context.view_layer.objects.active = target
    mod = target.modifiers.new('Boolean cut', 'BOOLEAN')
    mod.operation = 'DIFFERENCE'
    mod.solver = 'EXACT'
    mod.object = cutter
    select_only([target])
    try:
        bpy.ops.object.modifier_apply(modifier=mod.name)
    except Exception as e:
        print('BOOLEAN_FAIL', target.name, repr(e))
        target.modifiers.remove(mod)
    if cutter.name in bpy.data.objects:
        bpy.data.objects.remove(cutter, do_unlink=True)
    return target


def bolt(location, normal=(1, 0, 0), radius=0.0042, depth=0.0035, shank=0.012, mat=None):
    if mat is None:
        mat = M_ZINC
    normal = Vector(normal).normalized()
    q = normal.to_track_quat('Z', 'Y')
    things = []
    center = Vector(location)
    # washer
    bpy.ops.mesh.primitive_cylinder_add(vertices=20, radius=radius * 1.35, depth=0.0012,
                                        location=center + normal * 0.0006, rotation=q.to_euler())
    w = bpy.context.object
    w.name = 'BoltWasher'
    assign(w, M_STEEL_DARK)
    bevel(w, 0.0002, 1)
    things.append(w)
    # hex head
    bpy.ops.mesh.primitive_cylinder_add(vertices=6, radius=radius, depth=depth,
                                        location=center + normal * (depth / 2 + 0.0012), rotation=q.to_euler())
    h = bpy.context.object
    h.name = 'BoltHead'
    assign(h, mat)
    bevel(h, 0.0005, 2)
    shade(h)
    things.append(h)
    # shank
    bpy.ops.mesh.primitive_cylinder_add(vertices=12, radius=radius * 0.55, depth=shank,
                                        location=center - normal * (shank / 2), rotation=q.to_euler())
    s = bpy.context.object
    s.name = 'BoltShank'
    assign(s, mat)
    things.append(s)
    return things


# ---------------------------------------------------------------------------
# Materials
# ---------------------------------------------------------------------------
def srgb(hex_value):
    h = hex_value.lstrip('#')
    vals = [int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4)]
    return tuple((v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4) for v in vals)


def mat_principled(name, color, metallic=0.0, roughness=0.5, coat=0.0, coat_rough=0.2, noise=None):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    out = nodes.new('ShaderNodeOutputMaterial')
    bsdf = nodes.new('ShaderNodeBsdfPrincipled')
    out.location = (300, 0)
    bsdf.location = (0, 0)
    links.new(bsdf.outputs['BSDF'], out.inputs['Surface'])
    bsdf.inputs['Base Color'].default_value = (*color, 1.0)
    bsdf.inputs['Metallic'].default_value = metallic
    bsdf.inputs['Roughness'].default_value = roughness
    # Keep Solid-mode viewport display in sync with the shader colour.
    mat.diffuse_color = (*color, 1.0)
    mat.metallic = metallic
    mat.roughness = roughness
    if 'Coat Weight' in bsdf.inputs:
        bsdf.inputs['Coat Weight'].default_value = coat
        bsdf.inputs['Coat Roughness'].default_value = coat_rough
    if noise:
        (scale, strength) = noise
        tex = nodes.new('ShaderNodeTexNoise')
        tex.inputs['Scale'].default_value = scale
        tex.inputs['Detail'].default_value = 4.0
        tex.inputs['Roughness'].default_value = 0.65
        bump = nodes.new('ShaderNodeBump')
        bump.inputs['Strength'].default_value = strength
        bump.inputs['Distance'].default_value = 0.02
        links.new(tex.outputs['Fac'], bump.inputs['Height'])
        links.new(bump.outputs['Normal'], bsdf.inputs['Normal'])
    return mat


def make_image_mat(name, image_path, metallic=0.5, roughness=0.35, specular=0.3,
                   viewport_color=(0.45, 0.48, 0.49, 1.0)):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    out = nodes.new('ShaderNodeOutputMaterial')
    bsdf = nodes.new('ShaderNodeBsdfPrincipled')
    links.new(bsdf.outputs['BSDF'], out.inputs['Surface'])
    img = bpy.data.images.load(image_path, check_existing=True)
    img.colorspace_settings.name = 'sRGB'
    tex = nodes.new('ShaderNodeTexImage')
    tex.image = img
    tex.interpolation = 'Cubic'
    links.new(tex.outputs['Color'], bsdf.inputs['Base Color'])
    bsdf.inputs['Metallic'].default_value = metallic
    bsdf.inputs['Roughness'].default_value = roughness
    if 'Specular IOR Level' in bsdf.inputs:
        bsdf.inputs['Specular IOR Level'].default_value = specular
    elif 'Specular' in bsdf.inputs:
        bsdf.inputs['Specular'].default_value = specular
    mat.diffuse_color = viewport_color
    return mat


def make_lamination_mat():
    mat = bpy.data.materials.new('Lamination_Steel')
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    out = nodes.new('ShaderNodeOutputMaterial')
    bsdf = nodes.new('ShaderNodeBsdfPrincipled')
    links.new(bsdf.outputs['BSDF'], out.inputs['Surface'])
    bsdf.inputs['Metallic'].default_value = 0.92
    bsdf.inputs['Roughness'].default_value = 0.31
    wave = nodes.new('ShaderNodeTexWave')
    wave.wave_type = 'BANDS'
    wave.bands_direction = 'X'
    wave.wave_profile = 'SIN'
    wave.inputs['Scale'].default_value = 120.0
    wave.inputs['Distortion'].default_value = 0.15
    wave.inputs['Detail'].default_value = 2.0
    ramp = nodes.new('ShaderNodeValToRGB')
    ramp.color_ramp.elements[0].position = 0.30
    ramp.color_ramp.elements[0].color = (*srgb('#4A5254'), 1)
    ramp.color_ramp.elements[1].position = 0.78
    ramp.color_ramp.elements[1].color = (*srgb('#CDD4D6'), 1)
    links.new(wave.outputs['Fac'], ramp.inputs['Fac'])
    links.new(ramp.outputs['Color'], bsdf.inputs['Base Color'])
    bump = nodes.new('ShaderNodeBump')
    bump.inputs['Strength'].default_value = 0.32
    bump.inputs['Distance'].default_value = 0.0016
    links.new(wave.outputs['Fac'], bump.inputs['Height'])
    links.new(bump.outputs['Normal'], bsdf.inputs['Normal'])
    return mat


M_PAINT = mat_principled('Paint_Teal', srgb('#203B43'), 0.34, 0.40, coat=0.18, coat_rough=0.45, noise=(65, 0.10))
M_PAINT_DARK = mat_principled('Paint_Deep', srgb('#12272D'), 0.30, 0.48, coat=0.12, coat_rough=0.5, noise=(70, 0.10))
M_STEEL = mat_principled('Steel', srgb('#B9C2C5'), 0.95, 0.28, noise=(120, 0.03))
M_STEEL_DARK = mat_principled('Steel_Dark', srgb('#586468'), 0.9, 0.38)
M_STEEL_BRIGHT = mat_principled('Steel_Bright', srgb('#D4DADD'), 1.0, 0.19)
M_CAST = mat_principled('Cast_Iron', srgb('#20272A'), 0.55, 0.58, noise=(40, 0.20))
M_ALU = mat_principled('Aluminium', srgb('#B4BCBE'), 0.85, 0.34, noise=(90, 0.05))
M_COPPER = mat_principled('Copper', srgb('#B96B3A'), 1.0, 0.25, coat=0.1, coat_rough=0.35, noise=(60, 0.04))
M_COPPER_DARK = mat_principled('Copper_Dark', srgb('#7F4725'), 0.9, 0.36)
M_BRASS = mat_principled('Brass', srgb('#C9A45E'), 1.0, 0.29)
M_ZINC = mat_principled('Zinc', srgb('#C7CCCB'), 0.8, 0.36)
M_RUBBER = mat_principled('Rubber', srgb('#101314'), 0.02, 0.9)
M_PLASTIC = mat_principled('Plastic_Black', srgb('#171A1B'), 0.1, 0.46, noise=(120, 0.04))
M_INSULATION = mat_principled('Insulation', srgb('#7B4A28'), 0.05, 0.78)
M_LAMINATION = make_lamination_mat()
M_CERAMIC = mat_principled('Ceramic', srgb('#D7D1C2'), 0.0, 0.54)
M_FLOOR = mat_principled('Studio_Floor', srgb('#060B0D'), 0.18, 0.36, noise=(6, 0.06))
M_STAGE = mat_principled('Stage_Metal', srgb('#0C171A'), 0.45, 0.32, coat=0.2, coat_rough=0.3, noise=(30, 0.05))
M_LABEL_NAME = make_image_mat('Nameplate_Print', os.path.join(ASSETS, 'nameplate.png'), 0.35, 0.36, 0.35)
M_LABEL_WARN = make_image_mat('Warning_Print', os.path.join(ASSETS, 'warning.png'), 0.0, 0.78, 0.08)
M_LABEL_BRAND = make_image_mat('Brand_Print', os.path.join(ASSETS, 'brand.png'), 0.25, 0.4, 0.2)


# ---------------------------------------------------------------------------
# Studio
# ---------------------------------------------------------------------------
def build_stage():
    # continuous dark floor
    bpy.ops.mesh.primitive_plane_add(size=30, location=(0, 0, -0.031))
    floor = bpy.context.object
    floor.name = 'Studio_Floor'
    assign(floor, M_FLOOR)
    link_to(floor, C_STAGE)

    # raised circular plinth; top at z = 0 so the motor feet rest on it
    bpy.ops.mesh.primitive_cylinder_add(vertices=128, radius=0.82, depth=0.031, location=(0, 0, -0.0155))
    plinth = bpy.context.object
    plinth.name = 'Stage_Plinth'
    assign(plinth, M_STAGE)
    bevel(plinth, 0.005, 3)
    shade(plinth)
    link_to(plinth, C_STAGE)

    # concentric machined grooves
    for r in (0.36, 0.58, 0.79):
        t = torus('Stage_Groove', r, 0.0008, (0, 0, 0.0002), axis='Z', mat=M_STEEL_DARK,
                  major_seg=128, minor_seg=5, coll=C_STAGE)
        t.scale = (1, 1, 1)
    # small index marks
    for i in range(48):
        a = TAU * i / 48
        long = (i % 4 == 0)
        length = 0.055 if long else 0.02
        x, y = math.cos(a) * 0.73, math.sin(a) * 0.73
        tick = box('Stage_Tick', (0.0015, length, 0.0006), (x, y, 0.0005),
                   (0, 0, a), mat=M_STEEL_DARK, bev=0, coll=C_STAGE)


def add_area(name, loc, energy, size, color, target=(0, 0, 0.25)):
    data = bpy.data.lights.new(name, 'AREA')
    data.energy = energy
    data.shape = 'DISK'
    data.size = size
    data.color = color
    obj = bpy.data.objects.new(name, data)
    C_LIGHTS.objects.link(obj)
    obj.location = loc
    d = Vector(target) - Vector(loc)
    obj.rotation_euler = d.to_track_quat('-Z', 'Y').to_euler()
    return obj


def build_lights():
    world = bpy.data.worlds.new('Studio_World')
    SCENE.world = world
    world.use_nodes = True
    bg = world.node_tree.nodes['Background']
    bg.inputs['Color'].default_value = (*srgb('#071114'), 1)
    bg.inputs['Strength'].default_value = 0.8

    add_area('Key_Softbox', (1.35, -1.5, 1.6), 260, 2.0, (1.0, 0.88, 0.74), (0, 0, 0.18))
    add_area('Fill_Softbox', (-1.35, -1.15, 0.9), 105, 2.2, (0.58, 0.82, 0.92), (0, 0, 0.17))
    add_area('Rim_Softbox', (-0.75, 1.15, 1.45), 200, 1.1, (0.58, 0.82, 0.90), (0, 0, 0.22))
    add_area('Top_Softbox', (0.1, 0.0, 2.2), 120, 1.4, (0.78, 0.90, 0.92), (0, 0, 0.2))
    add_area('Warm_Accent', (1.8, 0.3, 0.3), 22, 0.5, (1.0, 0.45, 0.12), (0, 0, 0.15))


def build_camera():
    target = bpy.data.objects.new('CAM_TARGET', None)
    C_CAM.objects.link(target)
    target.location = (0, 0, 0.17)
    cam_data = bpy.data.cameras.new('Product_Camera')
    cam = bpy.data.objects.new('Product_Camera', cam_data)
    C_CAM.objects.link(cam)
    cam.location = (1.08, -1.55, 0.68)
    cam.data.lens = 55
    cam.data.sensor_width = 36
    cam.data.dof.use_dof = True
    cam.data.dof.focus_object = target
    cam.data.dof.aperture_fstop = 8.0
    con = cam.constraints.new('TRACK_TO')
    con.target = target
    con.track_axis = 'TRACK_NEGATIVE_Z'
    con.up_axis = 'UP_Y'
    SCENE.camera = cam
    return cam, target


# ---------------------------------------------------------------------------
# Part helpers
# ---------------------------------------------------------------------------
def make_bolt_on_face(target_objs, pos, normal, **kwargs):
    target_objs.extend(bolt(pos, normal, **kwargs))


def build_frame():
    objs = []
    shell = revolve_x(
        'FrameShell',
        [(0.103, -0.17), (0.127, -0.17), (0.130, -0.162), (0.130, 0.162),
         (0.127, 0.17), (0.103, 0.17), (0.103, -0.17)],
        M_PAINT, segments=96
    )
    bevel(shell, 0.0025, 2)
    objs.append(shell)

    # cooling fins around the barrel
    fin_count = 32
    for i in range(fin_count):
        a = TAU * i / fin_count
        aa = math.atan2(math.sin(a), math.cos(a))
        if abs(aa) < 0.40 or abs(abs(aa) - math.pi) < 0.38:
            continue
        if abs(abs(aa) - math.pi / 2) < 0.23:
            continue
        r = 0.139
        fin = box('Fin', (0.316, 0.006, 0.026), (0, -math.sin(a) * r, math.cos(a) * r),
                  (a, 0, 0), mat=M_PAINT, bev=0.0016)
        objs.append(fin)

    # end rims
    for x in (-0.165, 0.165):
        t = torus('FrameRim', 0.1295, 0.0032, (x, 0, 0), axis='X', mat=M_PAINT,
                  major_seg=96, minor_seg=10)
        objs.append(t)

    # feet and webs
    for sy in (-1, 1):
        foot = box('FootRail', (0.32, 0.10, 0.026), (0, sy * 0.102, -0.119),
                   mat=M_PAINT, bev=0.006)
        objs.append(foot)
        web = box('FootWeb', (0.22, 0.046, 0.038), (0, sy * 0.104, -0.092),
                  mat=M_PAINT, bev=0.004)
        objs.append(web)
        for sx in (-1, 1):
            pad = box('FootPad', (0.08, 0.085, 0.012), (sx * 0.068, sy * 0.104, -0.101),
                      mat=M_PAINT_DARK, bev=0.002)
            objs.append(pad)
            hole = cyl('FootHole', 0.009, 0.02, (sx * 0.068, sy * 0.104, -0.105),
                       axis='Z', mat=M_RUBBER, verts=28, bev=0)
            objs.append(hole)
            for side in (-1, 1):
                objs.append(box('FootBoltPad', (0.034, 0.0025, 0.012),
                                (sx * 0.068 + side * 0.014, sy * 0.104 + side * 0.019, -0.108),
                                mat=M_PAINT_DARK, bev=0.001))

    # mounting pads for terminal box / eye / nameplate
    objs.append(box('TerminalPad', (0.15, 0.11, 0.013), (0.035, 0, 0.128),
                    mat=M_PAINT_DARK, bev=0.003))
    objs.append(cyl('EyePad', 0.024, 0.012, (-0.09, 0, 0.130), axis='Z', mat=M_PAINT_DARK,
                    verts=32, bev=0.001))
    objs.append(box('NameplatePad', (0.124, 0.007, 0.084), (0.03, -0.130, 0.018),
                    mat=M_PAINT_DARK, bev=0.002))

    # drain and grounding bosses
    drain = cyl('DrainPlug', 0.008, 0.012, (0.11, -0.094, 0.06), axis='Y', mat=M_BRASS,
                verts=6, bev=0.0005)
    objs.append(drain)
    ground = cyl('GroundBoss', 0.011, 0.012, (-0.11, -0.075, 0.09), axis='Y', mat=M_STEEL,
                 verts=6, bev=0.0005)
    objs.append(ground)
    objs.extend(bolt((-0.11, -0.083, 0.09), (0, -1, 0), radius=0.004, shank=0.01))

    # nameplate mounting rivets
    for x, z in ((-0.02, 0.034), (-0.02, -0.002), (0.08, 0.034), (0.08, -0.002)):
        objs.extend(bolt((x, -0.134, z), (0, -1, 0), radius=0.0032, depth=0.0018, shank=0.004))

    # terminal box mounting bolts
    for x, y in ((0.0, -0.045), (0.0, 0.045), (0.07, -0.045), (0.07, 0.045)):
        objs.extend(bolt((x, y, 0.134), (0, 0, 1), radius=0.0035, depth=0.003, shank=0.012))

    obj = join_objects(objs, 'StatorFrame')
    return obj


def build_endshield(front):
    outward = 1 if front else -1
    objs = []
    plate = cyl('ShieldPlate', 0.138, 0.028, (0, 0, 0), axis='X', mat=M_PAINT_DARK, verts=96, bev=0)
    # cutters: bearing bore, vents, mounting bolts
    cutters = []
    cutters.append(cyl('CutBore', 0.0468, 0.05, (0, 0, 0), axis='X', mat=None, verts=64, bev=0))
    for i in range(6):
        a = math.pi / 6 + TAU * i / 6
        cutters.append(cyl('CutVent', 0.0182, 0.05,
                           (0, math.cos(a) * 0.0875, math.sin(a) * 0.0875),
                           axis='X', mat=None, verts=32, bev=0))
    for i in range(4):
        a = math.pi / 4 + TAU * i / 4
        cutters.append(cyl('CutBolt', 0.0052, 0.05,
                           (0, math.cos(a) * 0.124, math.sin(a) * 0.124),
                           axis='X', mat=None, verts=20, bev=0))
    boolean_cut(plate, cutters)
    bevel(plate, 0.0022, 2)
    shade(plate)
    objs.append(plate)

    # raised bearing boss on the outside face
    boss = revolve_x('BearingBoss', ring_profile(0.0468, 0.059, outward * 0.009, outward * 0.028),
                     M_PAINT_DARK, segments=64)
    objs.append(boss)
    # seal seat ring
    objs.append(torus('BossSeat', 0.0575, 0.0022, (outward * 0.028, 0, 0), axis='X',
                      mat=M_STEEL_DARK, major_seg=64, minor_seg=8))
    # ribs
    for i in range(4):
        a = math.pi / 4 + TAU * i / 4 + math.pi / 4
        rib = box('Rib', (0.012, 0.008, 0.066), (outward * 0.014, math.cos(a) * 0.085,
                  math.sin(a) * 0.085), (0, 0, 0), mat=M_PAINT_DARK, bev=0.0016)
        # Rotate the rib to point radially around X.
        rib.rotation_euler = (a - math.pi / 2, 0, 0)
        apply_transform(rib)
        objs.append(rib)
    # vent lips
    for i in range(6):
        a = math.pi / 6 + TAU * i / 6
        objs.append(torus('VentLip', 0.0188, 0.0016,
                          (outward * 0.0145, math.cos(a) * 0.0875, math.sin(a) * 0.0875),
                          axis='X', mat=M_PAINT_DARK, major_seg=32, minor_seg=6))
    # mounting bolts
    for i in range(4):
        a = math.pi / 4 + TAU * i / 4
        objs.extend(bolt((outward * 0.015, math.cos(a) * 0.124, math.sin(a) * 0.124),
                         (outward, 0, 0), radius=0.0058, depth=0.004, shank=0.045))
    # spigot seat inside the frame
    objs.append(revolve_x('Spigot', ring_profile(0.092, 0.101, -outward * 0.023, -outward * 0.009),
                          M_STEEL_DARK, segments=80))
    obj = join_objects(objs, 'FrontEndShield' if front else 'RearEndShield')
    return obj


def build_bearing_cover(front):
    outward = 1 if front else -1
    objs = []
    center_hole = 0.0245 if front else 0.0
    plate = cyl('CoverPlate', 0.057, 0.011, (0, 0, 0), axis='X', mat=M_PAINT_DARK, verts=64, bev=0)
    cutters = []
    if center_hole:
        cutters.append(cyl('CutBore', center_hole, 0.04, (0, 0, 0), axis='X', mat=None, verts=48, bev=0))
    for i in range(4):
        a = math.pi / 4 + TAU * i / 4
        cutters.append(cyl('CutBolt', 0.0036, 0.04,
                           (0, math.cos(a) * 0.0405, math.sin(a) * 0.0405),
                           axis='X', mat=None, verts=16, bev=0))
    boolean_cut(plate, cutters)
    bevel(plate, 0.0012, 2)
    shade(plate)
    objs.append(plate)
    objs.append(revolve_x('CoverLip', ring_profile(0.039, 0.046, outward * 0.004, outward * 0.012),
                          M_PAINT_DARK, segments=64))
    if front:
        objs.append(torus('SealRing', 0.0252, 0.002, (outward * 0.007, 0, 0), axis='X',
                          mat=M_RUBBER, major_seg=48, minor_seg=8))
    else:
        objs.append(cyl('GreaseHex', 0.009, 0.008, (outward * 0.008, 0, 0), axis='X',
                        mat=M_BRASS, verts=6, bev=0.0003))
        objs.append(cyl('GreaseNipple', 0.004, 0.014, (outward * 0.017, 0, 0), axis='X',
                        mat=M_BRASS, verts=12, bev=0.0003))
    for i in range(4):
        a = math.pi / 4 + TAU * i / 4
        objs.extend(bolt((outward * 0.0055, math.cos(a) * 0.0405, math.sin(a) * 0.0405),
                         (outward, 0, 0), radius=0.0035, depth=0.003, shank=0.012))
    objs.append(torus('FitRing', 0.0462, 0.0013, (outward * 0.006, 0, 0), axis='X',
                      mat=M_STEEL, major_seg=48, minor_seg=6))
    obj = join_objects(objs, 'FrontBearingCover' if front else 'RearBearingCover')
    return obj


def build_bearing():
    objs = [
        revolve_x('OuterRace', ring_profile(0.0402, 0.045, -0.0115, 0.0115), M_STEEL, segments=80),
        revolve_x('InnerRace', ring_profile(0.0201, 0.0249, -0.0115, 0.0115), M_STEEL, segments=64),
    ]
    for i in range(9):
        a = TAU * i / 9
        objs.append(sphere('Ball', 0.00755, (0, math.cos(a) * 0.0326, math.sin(a) * 0.0326),
                           mat=M_STEEL_BRIGHT, segments=20, rings=14))
    for side in (-1, 1):
        objs.append(torus('CageRail', 0.0326, 0.0011, (side * 0.0067, 0, 0), axis='X',
                          mat=M_BRASS, major_seg=48, minor_seg=5))
        for i in range(9):
            a = TAU * i / 9 + side * 0.045
            rr = 0.0326 + 0.00755 * 0.88
            objs.append(box('CageBar', (0.0018, 0.0016, 0.0058),
                            (side * 0.0045, math.cos(a) * rr, math.sin(a) * rr),
                            (a + math.pi / 2, 0, 0), mat=M_BRASS, bev=0.0002))
    obj = join_objects(objs, 'Bearing')
    return obj


def build_shaft():
    profile = [
        (0.0, -0.27), (0.012, -0.27), (0.013, -0.26), (0.013, -0.245),
        (0.0185, -0.235), (0.0185, -0.198), (0.022, -0.185), (0.0255, -0.15),
        (0.0255, 0.105), (0.022, 0.115), (0.022, 0.155), (0.0185, 0.168),
        (0.0185, 0.207), (0.022, 0.212), (0.022, 0.226), (0.0192, 0.233),
        (0.0192, 0.295), (0.0182, 0.302), (0.0, 0.31),
    ]
    shaft = revolve_x('ShaftBody', profile, M_STEEL, segments=96)
    # keyway dark inlay
    kw = box('Keyway', (0.054, 0.0018, 0.0105), (0.266, 0, 0.0192), mat=M_STEEL_DARK, bev=0.0004)
    # dark center holes
    holes = [
        cyl('CenterHoleFront', 0.0042, 0.002, (0.310, 0, 0), axis='X', mat=M_STEEL_DARK, verts=24, bev=0),
        cyl('CenterHoleRear', 0.0042, 0.002, (-0.270, 0, 0), axis='X', mat=M_STEEL_DARK, verts=24, bev=0),
    ]
    # bearing-seat machining grooves
    grooves = []
    for x in (-0.226, -0.174, -0.152, 0.108, 0.168, 0.207):
        grooves.append(torus('ShaftGroove', 0.0188 if abs(x) > 0.2 else 0.026, 0.00055,
                             (x, 0, 0), axis='X', mat=M_STEEL_DARK, major_seg=64, minor_seg=4))
    objs = [shaft, kw] + holes + grooves
    obj = join_objects(objs, 'Shaft')
    return obj


def build_shaft_key():
    key = box('ShaftKey', (0.05, 0.0075, 0.010), (0, 0, 0), mat=M_STEEL_BRIGHT, bev=0.0012)
    return join_objects([key], 'ShaftKey')


def build_rotor_core():
    body = revolve_x('RotorCoreBody', ring_profile(0.0261, 0.056, -0.0695, 0.0695), M_LAMINATION, segments=96)
    # end plates
    objs = [body]
    for x in (-0.0715, 0.0715):
        objs.append(revolve_x('RotorEndPlate', ring_profile(0.026, 0.0566, x - 0.002, x + 0.002),
                              M_STEEL_DARK, segments=80))
    # surface slot grooves
    for i in range(28):
        a = TAU * i / 28
        objs.append(box('RotorSlotGroove', (0.139, 0.0064, 0.0027),
                        (0, math.cos(a) * 0.055, math.sin(a) * 0.055), (a, 0, 0),
                        mat=M_STEEL_DARK, bev=0.0002))
    objs.append(torus('RotorBoreRim', 0.0263, 0.0011, (0.072, 0, 0), axis='X',
                      mat=M_STEEL_DARK, major_seg=56, minor_seg=5))
    obj = join_objects(objs, 'RotorCore')
    return obj


def build_rotor_cage():
    objs = []
    for i in range(28):
        a = TAU * i / 28
        objs.append(box('CageBar', (0.17, 0.0072, 0.0075),
                        (0, math.cos(a) * 0.052, math.sin(a) * 0.052), (a, 0, 0),
                        mat=M_ALU, bev=0.0008))
    for x in (-0.086, 0.086):
        objs.append(revolve_x('EndRing', ring_profile(0.035, 0.0635, x - 0.0095, x + 0.0095),
                              M_ALU, segments=80))
        objs.append(torus('EndRingLip', 0.0608, 0.0018, (x + (0.0095 if x > 0 else -0.0095), 0, 0),
                          axis='X', mat=M_ALU, major_seg=64, minor_seg=6))
        for i in range(3):
            a = TAU * i / 3 + 0.3
            objs.append(cyl('BalanceBoss', 0.0065, 0.01, (x * 1.12, math.cos(a) * 0.0575,
                          math.sin(a) * 0.0575), axis='X', mat=M_ALU, verts=16, bev=0.0003))
    obj = join_objects(objs, 'RotorCage')
    return obj


def build_stator_core():
    # A thick ring plus inward-projecting teeth creates the 36 open stator slots
    # without destructive booleans. This reads as a proper slotted lamination stack.
    core = revolve_x('StatorRing', ring_profile(0.0764, 0.1025, -0.07, 0.07), M_LAMINATION, segments=96)
    objs = [core]
    for i in range(36):
        a = TAU * (i + 0.5) / 36
        tooth = box('StatorTooth', (0.14, 0.0050, 0.0192),
                    (0, math.cos(a) * 0.0674, math.sin(a) * 0.0674), (a, 0, 0),
                    mat=M_LAMINATION, bev=0.0006)
        objs.append(tooth)
    for x in (-0.0715, 0.0715):
        objs.append(revolve_x('StatorEndPlate', ring_profile(0.0865, 0.1029, x - 0.003, x + 0.003),
                              M_STEEL_DARK, segments=96))
    for i in range(4):
        a = math.pi / 4 + TAU * i / 4
        objs.append(box('ClampFinger', (0.15, 0.007, 0.009),
                        (0, math.cos(a) * 0.101, math.sin(a) * 0.101), (a, 0, 0),
                        mat=M_STEEL_DARK, bev=0.001))
    # ventilation grooves around the outside
    for x in (-0.045, 0.045):
        objs.append(torus('CoreBand', 0.091, 0.0012, (x, 0, 0), axis='X',
                          mat=M_STEEL_DARK, major_seg=96, minor_seg=5))
    obj = join_objects(objs, 'StatorCore')
    return obj


def winding_curve(name, points, radius, mat=M_COPPER):
    curve = bpy.data.curves.new(name, 'CURVE')
    curve.dimensions = '3D'
    curve.resolution_u = 6
    curve.bevel_depth = radius
    curve.bevel_resolution = 2
    spline = curve.splines.new('BEZIER')
    spline.bezier_points.add(len(points) - 1)
    for i, co in enumerate(points):
        p = spline.bezier_points[i]
        p.co = co
        p.handle_left_type = 'AUTO'
        p.handle_right_type = 'AUTO'
    spline.use_cyclic_u = True
    obj = bpy.data.objects.new(name, curve)
    C_MOTOR.objects.link(obj)
    select_only([obj])
    bpy.ops.object.convert(target='MESH')
    obj = bpy.context.object
    assign(obj, mat)
    shade(obj, 35)
    return obj


def build_stator_winding():
    objs = []
    coils = 36
    for i in range(coils):
        a1 = TAU * i / coils
        a2 = a1 + math.pi * 4 / 9  # 8-slot pitch on a 36-slot stator
        layer = i % 2
        r = 0.0658 + layer * 0.0046
        bulge = 0.0120 + layer * 0.0045
        xend = 0.082 + layer * 0.005
        side = 0.074
        pts = []
        # side 1 to +X
        pts.append((math.cos(a1) * r, math.sin(a1) * r, -side))
        pts.append((math.cos(a1) * r, math.sin(a1) * r, side))
        # end turn at +X
        for t in (0.18, 0.38, 0.58, 0.78, 0.92):
            a = a1 + (a2 - a1) * t
            rr = r + bulge * math.sin(math.pi * t)
            x = xend + 0.010 * math.sin(math.pi * t)
            pts.append((math.cos(a) * rr, math.sin(a) * rr, x))
        pts.append((math.cos(a2) * r, math.sin(a2) * r, side))
        pts.append((math.cos(a2) * r, math.sin(a2) * r, -side))
        # end turn at -X
        for t in (0.18, 0.38, 0.58, 0.78, 0.92):
            a = a2 - (a2 - a1) * t
            rr = r + bulge * math.sin(math.pi * t)
            x = -xend - 0.010 * math.sin(math.pi * t)
            pts.append((math.cos(a) * rr, math.sin(a) * rr, x))
        # Convert convenient (Y,Z,X) list to Blender axial-X coordinates.
        pts3 = [(x, y, z) for (y, z, x) in pts]
        objs.append(winding_curve('Coil', pts3, 0.0027, M_COPPER))

    # paper phase barriers
    for x in (-0.088, 0.088):
        objs.append(torus('WindingBarrier', 0.079, 0.0014, (x, 0, 0), axis='X',
                          mat=M_INSULATION, major_seg=96, minor_seg=5))
    # lacing ties
    for x in (-0.095, 0.095):
        for i in range(12):
            a = TAU * i / 12
            objs.append(box('LacingTie', (0.0025, 0.012, 0.0025),
                            (x, math.cos(a) * 0.079, math.sin(a) * 0.079),
                            (a, 0, 0), mat=M_INSULATION, bev=0.0003))
    # phase leads
    leads = []
    for idx, (a, color) in enumerate(((math.radians(56), M_INSULATION), (math.radians(90), M_RUBBER),
                                       (math.radians(124), M_COPPER_DARK))):
        pts = [(math.cos(a) * 0.082, math.sin(a) * 0.082, 0.11),
               (math.cos(a) * 0.09, math.sin(a) * 0.09, 0.15),
               (0.035, 0.12, 0.19)]
        pts3 = [(x, y, z) for (y, z, x) in pts]
        leads.append(winding_curve('PhaseLead', pts3, 0.0045, color))
    objs.extend(leads)
    obj = join_objects(objs, 'StatorWinding')
    return obj


def fan_blade(name, length, width, thickness, theta, r, pitch=0.18, mat=None):
    b = box(name, (thickness, length, width), (0, 0, 0), mat=mat or M_PLASTIC, bev=0.0012)
    # Pitch around the radial Y axis, then position around X.
    b.data.transform(Matrix.Rotation(pitch, 4, 'Y'))
    b.data.transform(Matrix.Rotation(theta, 4, 'X'))
    b.location = (0, math.cos(theta) * r, math.sin(theta) * r)
    return b


def build_external_fan():
    objs = [
        cyl('FanHub', 0.039, 0.032, (0, 0, 0), axis='X', mat=M_PLASTIC, verts=48, bev=0.0015),
        cyl('FanInsert', 0.02, 0.008, (0.018, 0, 0), axis='X', mat=M_STEEL_DARK, verts=32, bev=0.0005),
        torus('FanFaceRing', 0.041, 0.0022, (0.017, 0, 0), axis='X', mat=M_PLASTIC_DARK if False else M_PLASTIC,
              major_seg=48, minor_seg=6),
    ]
    for i in range(11):
        objs.append(fan_blade('FanBlade', 0.079, 0.031, 0.006, TAU * i / 11, 0.067, pitch=0.28))
    # retaining bolt
    objs.extend(bolt((0.026, 0, 0), (1, 0, 0), radius=0.007, depth=0.0045, shank=0.014))
    obj = join_objects(objs, 'CoolingFan')
    return obj


def build_internal_fan():
    objs = [
        cyl('InnerFanHub', 0.029, 0.028, (0, 0, 0), axis='X', mat=M_INSULATION, verts=48, bev=0.0012),
        torus('InnerFanRing', 0.033, 0.0018, (0.014, 0, 0), axis='X', mat=M_STEEL_DARK,
              major_seg=48, minor_seg=5),
    ]
    for i in range(9):
        objs.append(fan_blade('InnerFanBlade', 0.058, 0.021, 0.004, TAU * i / 9, 0.058,
                              pitch=0.34, mat=M_INSULATION))
    obj = join_objects(objs, 'RotorFan')
    return obj


def build_fan_cover():
    profile = [
        (0.124, 0.045), (0.124, -0.020), (0.121, -0.034), (0.107, -0.047),
        (0.074, -0.056), (0.046, -0.059), (0.043, -0.052), (0.069, -0.048),
        (0.102, -0.040), (0.116, -0.028), (0.118, -0.014), (0.118, 0.045),
        (0.124, 0.045),
    ]
    objs = [revolve_x('FanCoverShroud', profile, M_PAINT_DARK, segments=96)]
    objs.append(torus('FanCoverRim', 0.1215, 0.0032, (0.045, 0, 0), axis='X',
                      mat=M_STEEL_DARK, major_seg=96, minor_seg=8))
    objs.append(torus('FanCoverInnerRim', 0.057, 0.0022, (-0.056, 0, 0), axis='X',
                      mat=M_STEEL_DARK, major_seg=64, minor_seg=6))
    # grille rings and spokes at the open rear face
    for r in (0.058, 0.077, 0.096, 0.113):
        objs.append(torus('GrilleRing', r, 0.0017, (-0.059, 0, 0), axis='X',
                          mat=M_STEEL_DARK, major_seg=72, minor_seg=5))
    for i in range(8):
        a = TAU * i / 8
        objs.append(box('GrilleSpoke', (0.0028, 0.0028, 0.060),
                        (-0.059, math.cos(a) * 0.085, math.sin(a) * 0.085),
                        (a, 0, 0), mat=M_STEEL_DARK, bev=0.0002))
    objs.append(cyl('GrilleHub', 0.018, 0.016, (-0.051, 0, 0), axis='X',
                    mat=M_PAINT_DARK, verts=24, bev=0.001))
    # mounting tabs and bolts
    for i in range(4):
        a = math.pi / 4 + TAU * i / 4
        objs.append(box('CoverTab', (0.022, 0.018, 0.007),
                        (0.049, math.cos(a) * 0.118, math.sin(a) * 0.118),
                        (a - math.pi / 2, 0, 0), mat=M_PAINT, bev=0.002))
        objs.extend(bolt((0.0525, math.cos(a) * 0.118, math.sin(a) * 0.118),
                         (1, 0, 0), radius=0.0045, depth=0.0035, shank=0.012))
    # brand decal on side
    plate = box('BrandPlateBacking', (0.075, 0.002, 0.024), (0.0, -0.124, 0.015),
                mat=M_STEEL_DARK, bev=0.0005)
    objs.append(plate)
    objs.append(image_plane('BrandDecal', os.path.join(ASSETS, 'brand.png'),
                            (0.075, 0.024), (0.0, -0.126, 0.015), normal='-Y', mat=M_LABEL_BRAND))
    obj = join_objects(objs, 'FanCover')
    return obj


def image_plane(name, image_path, size, loc, normal='-Y', mat=None, coll=C_MOTOR):
    bpy.ops.mesh.primitive_plane_add(size=1, location=(0, 0, 0))
    obj = bpy.context.object
    obj.name = name
    obj.scale = (size[0], size[1], 1)
    apply_transform(obj)
    if normal == '-Y':
        obj.rotation_euler = (math.pi / 2, 0, 0)
    elif normal == '+Y':
        obj.rotation_euler = (-math.pi / 2, 0, 0)
    elif normal == '+Z':
        obj.rotation_euler = (0, 0, 0)
    elif normal == '+X':
        obj.rotation_euler = (0, math.pi / 2, 0)
    elif normal == '-X':
        obj.rotation_euler = (0, -math.pi / 2, 0)
    apply_transform(obj)
    obj.location = loc
    if mat is None:
        mat = make_image_mat(name + '_mat', image_path)
    assign(obj, mat)
    # image textures on planes should not be shaded smooth
    link_to(obj, coll)
    return obj


def build_terminal_box():
    objs = []
    body = box('TerminalBase', (0.15, 0.14, 0.065), (0, 0, 0), mat=M_PAINT_DARK, bev=0.007)
    # hollow cavity
    cut = box('TerminalCavity', (0.13, 0.12, 0.055), (0, 0, 0.012), mat=None, bev=0)
    boolean_cut(body, [cut])
    bevel(body, 0.003, 2)
    shade(body)
    objs.append(body)
    # top gasket
    for sx in (-1, 1):
        objs.append(box('TerminalGasket', (0.14, 0.009, 0.004), (0, sx * 0.0675, 0.034),
                        mat=M_RUBBER, bev=0.001))
    for sy in (-1, 1):
        objs.append(box('TerminalGasket', (0.009, 0.128, 0.004), (sy * 0.0675, 0, 0.034),
                        mat=M_RUBBER, bev=0.001))
    # ceramic terminal board and brass hardware
    board = box('TerminalBoard', (0.11, 0.10, 0.007), (0, 0, 0.015), mat=M_CERAMIC, bev=0.002)
    objs.append(board)
    for x in (-0.036, 0, 0.036):
        for y in (-0.032, 0.032):
            objs.append(cyl('Stud', 0.0053, 0.018, (x, y, 0.027), axis='Z', mat=M_BRASS,
                            verts=14, bev=0.0002))
            objs.append(cyl('StudNut', 0.0082, 0.005, (x, y, 0.038), axis='Z', mat=M_BRASS,
                            verts=6, bev=0.0003))
            objs.append(cyl('StudWasher', 0.010, 0.001, (x, y, 0.034), axis='Z', mat=M_STEEL_DARK,
                            verts=24, bev=0))
    # links
    for y in (-0.032, 0.032):
        objs.append(box('TerminalLink', (0.07, 0.007, 0.0028), (0, y, 0.033),
                        mat=M_BRASS, bev=0.0006))
    # cable gland on the rear and a short service cable
    objs.append(cyl('GlandBody', 0.014, 0.025, (-0.083, 0, 0.018), axis='X', mat=M_BRASS,
                    verts=6, bev=0.001))
    objs.append(cyl('GlandNut', 0.0165, 0.008, (-0.095, 0, 0.018), axis='X', mat=M_BRASS,
                    verts=6, bev=0.0006))
    objs.append(winding_curve('ServiceCable',
                              [(-0.085, 0.016, 0.012), (-0.115, 0.025, -0.005), (-0.13, 0.04, -0.035)],
                              0.0085, M_RUBBER))
    # warning / rating decal on the front face of the base
    objs.append(box('WarningBacking', (0.105, 0.002, 0.052), (0.0, -0.071, -0.003),
                    mat=M_PAINT_DARK, bev=0.0008))
    objs.append(image_plane('WarningDecal', os.path.join(ASSETS, 'warning.png'),
                            (0.098, 0.047), (0.0, -0.0725, -0.003), normal='-Y', mat=M_LABEL_WARN))
    # mounting feet
    for sx in (-1, 1):
        for sy in (-1, 1):
            objs.append(box('TerminalFoot', (0.02, 0.018, 0.008), (sx * 0.058, sy * 0.060, -0.036),
                            mat=M_PAINT_DARK, bev=0.002))
    # base mounting bolts
    for x, y in ((-0.06, -0.06), (0.06, -0.06), (-0.06, 0.06), (0.06, 0.06)):
        objs.extend(bolt((x, y, 0.027), (0, 0, 1), radius=0.0036, depth=0.003, shank=0.012))
    obj = join_objects(objs, 'TerminalBox')
    return obj


def build_terminal_lid():
    objs = []
    lid = box('TerminalLidPlate', (0.166, 0.156, 0.014), (0, 0, 0), mat=M_PAINT_DARK, bev=0.006)
    objs.append(lid)
    # stiffening ribs
    for x in (-0.05, 0.05):
        objs.append(box('LidRib', (0.012, 0.138, 0.003), (x, 0, 0.009), mat=M_PAINT_DARK, bev=0.001))
    for y in (-0.055, 0.055):
        objs.append(box('LidRib', (0.13, 0.012, 0.003), (0, y, 0.009), mat=M_PAINT_DARK, bev=0.001))
    objs.append(box('LidGasket', (0.148, 0.14, 0.004), (0, 0, -0.008), mat=M_RUBBER, bev=0.0018))
    for x, y in ((-0.069, -0.066), (0.069, -0.066), (-0.069, 0.066), (0.069, 0.066)):
        objs.extend(bolt((x, y, 0.008), (0, 0, 1), radius=0.0046, depth=0.0035, shank=0.014))
    obj = join_objects(objs, 'TerminalLid')
    return obj


def build_lifting_eye():
    objs = []
    objs.append(cyl('EyeBase', 0.019, 0.012, (0, 0, 0.006), axis='Z', mat=M_PAINT_DARK, verts=6, bev=0.001))
    objs.append(cyl('EyeStem', 0.009, 0.038, (0, 0, 0.03), axis='Z', mat=M_PAINT_DARK, verts=20, bev=0.0007))
    objs.append(torus('EyeRing', 0.017, 0.0052, (0, 0, 0.059), axis='Y', mat=M_PAINT_DARK,
                      major_seg=40, minor_seg=12))
    obj = join_objects(objs, 'LiftingEye')
    return obj


def build_nameplate():
    objs = []
    backing = box('NameplateBacking', (0.112, 0.004, 0.071), (0, 0, 0), mat=M_STEEL_BRIGHT, bev=0.001)
    objs.append(backing)
    face = image_plane('NameplateFace', os.path.join(ASSETS, 'nameplate.png'),
                       (0.104, 0.063), (0, -0.0023, 0), normal='-Y', mat=M_LABEL_NAME)
    objs.append(face)
    for x, z in ((-0.046, 0.028), (-0.046, -0.028), (0.046, 0.028), (0.046, -0.028)):
        objs.extend(bolt((x, -0.0035, z), (0, -1, 0), radius=0.0032, depth=0.0018, shank=0.004))
    obj = join_objects(objs, 'Nameplate')
    return obj


def build_shaft_seal():
    objs = [
        revolve_x('SealCase', ring_profile(0.0218, 0.0275, -0.004, 0.004), M_STEEL, segments=64),
        torus('SealLip', 0.0204, 0.0021, (0.0018, 0, 0), axis='X', mat=M_RUBBER, major_seg=48,
              minor_seg=8),
        torus('GarterSpring', 0.0201, 0.0007, (0.0035, 0, 0), axis='X', mat=M_STEEL,
              major_seg=48, minor_seg=5),
    ]
    return join_objects(objs, 'ShaftSeal')


def build_wave_spring():
    pts = []
    for i in range(160):
        a = TAU * i / 160
        pts.append((math.sin(a * 3) * 0.0018, 0.0405, a))
    # convert polar to X-axis wave ring
    coords = []
    for x, r, a in pts:
        coords.append((x, math.cos(a) * r, math.sin(a) * r))
    obj = winding_curve('WaveSpring', coords, 0.0011, M_STEEL)
    return join_objects([obj], 'WaveSpring')


# ---------------------------------------------------------------------------
# Assemble 22 parts
# ---------------------------------------------------------------------------
ROOT = bpy.data.objects.new('MOTOR_ROOT', None)
C_CTRL.objects.link(ROOT)
ROOT.empty_display_type = 'PLAIN_AXES'

PARTS = {}

PART_INFO = [
    ('fan-cover', 'FanCover', '01', 'Fan Cover', (0, 0, 0), (-0.57, 0.0, 0.06)),
    ('cooling-fan', 'CoolingFan', '02', 'External Cooling Fan', (0, 0, 0), (-0.44, 0.0, 0.03)),
    ('rear-bearing-cover', 'RearBearingCover', '03', 'Rear Bearing Cover', (0, 0, 0), (-0.30, 0.0, 0.02)),
    ('rear-bearing', 'RearBearing', '04', 'Rear Bearing 6308', (0, 0, 0), (-0.22, 0.0, 0.0)),
    ('rear-endshield', 'RearEndShield', '05', 'Rear End Shield', (0, 0, 0), (-0.14, 0.0, 0.0)),
    ('rotor-fan', 'RotorFan', '06', 'Internal Rotor Fan', (0, 0, 0), (-0.10, 0.0, -0.15)),
    ('shaft-key', 'ShaftKey', '07', 'Shaft Key', (0, 0, 0), (0.28, 0.0, -0.18)),
    ('shaft', 'Shaft', '08', 'Rotor Shaft', (0, 0, 0), (0.0, 0.0, -0.34)),
    ('rotor-cage', 'RotorCage', '09', 'Squirrel Cage', (0, 0, 0), (0.16, 0.0, -0.24)),
    ('rotor-core', 'RotorCore', '10', 'Rotor Core', (0, 0, 0), (-0.12, 0.0, -0.24)),
    ('stator-core', 'StatorCore', '11', 'Stator Core', (0, 0, 0), (0.02, 0.0, 0.12)),
    ('stator-winding', 'StatorWinding', '12', 'Stator Winding', (0, 0, 0), (0.22, 0.0, 0.12)),
    ('stator-frame', 'StatorFrame', '13', 'Stator Frame & Feet', (0, 0, 0), (0.32, 0.0, 0.38)),
    ('terminal-box', 'TerminalBox', '14', 'Terminal Box', (0, 0, 0), (0.05, 0.0, 0.46)),
    ('terminal-lid', 'TerminalLid', '15', 'Terminal Box Lid', (0, 0, 0), (0.05, 0.0, 0.58)),
    ('lifting-eye', 'LiftingEye', '16', 'Lifting Eye', (0, 0, 0), (-0.10, 0.0, 0.50)),
    ('nameplate', 'Nameplate', '17', 'Nameplate', (0, 0, 0), (-0.04, -0.24, 0.28)),
    ('front-endshield', 'FrontEndShield', '18', 'Front End Shield', (0, 0, 0), (0.18, 0.0, 0.0)),
    ('front-bearing', 'FrontBearing', '19', 'Front Bearing 6308', (0, 0, 0), (0.26, 0.0, 0.0)),
    ('front-bearing-cover', 'FrontBearingCover', '20', 'Front Bearing Cover', (0, 0, 0), (0.34, 0.0, 0.02)),
    ('shaft-seal', 'ShaftSeal', '21', 'Shaft Seal', (0, 0, 0), (0.30, 0.0, 0.08)),
    ('wave-spring', 'WaveSpring', '22', 'Wave Spring', (0, 0, 0), (-0.20, 0.0, -0.12)),
]


def make_part(part_id, name, index, label, pivot, explode):
    builder_map = {
        'FanCover': build_fan_cover,
        'CoolingFan': build_external_fan,
        'RearBearingCover': lambda: build_bearing_cover(False),
        'RearBearing': build_bearing,
        'RearEndShield': lambda: build_endshield(False),
        'RotorFan': build_internal_fan,
        'ShaftKey': build_shaft_key,
        'Shaft': build_shaft,
        'RotorCage': build_rotor_cage,
        'RotorCore': build_rotor_core,
        'StatorCore': build_stator_core,
        'StatorWinding': build_stator_winding,
        'StatorFrame': build_frame,
        'TerminalBox': build_terminal_box,
        'TerminalLid': build_terminal_lid,
        'LiftingEye': build_lifting_eye,
        'Nameplate': build_nameplate,
        'FrontEndShield': lambda: build_endshield(True),
        'FrontBearing': build_bearing,
        'FrontBearingCover': lambda: build_bearing_cover(True),
        'ShaftSeal': build_shaft_seal,
        'WaveSpring': build_wave_spring,
    }
    print('BUILD_PART', index, name)
    obj = builder_map[name]()
    obj.name = name
    obj.parent = ROOT
    obj.location = pivot
    obj['part_id'] = part_id
    obj['part_index'] = index
    obj['part_name'] = name
    obj['explode_offset'] = list(explode)
    obj['explode_start'] = 0.0
    obj['explode_end'] = 0.0
    PARTS[part_id] = (obj, Vector(explode))
    return obj


print('=== Building studio ===')
build_stage()
build_lights()
camera, cam_target = build_camera()

print('=== Building motor ===')
for info in PART_INFO:
    make_part(*info)

# set each part's pivot: specific axial/radial home positions
PIVOTS = {
    'FanCover': (-0.315, 0, CENTER_Z),
    'CoolingFan': (-0.272, 0, CENTER_Z),
    'RearBearingCover': (-0.229, 0, CENTER_Z),
    'RearBearing': (-0.190, 0, CENTER_Z),
    'RearEndShield': (-0.190, 0, CENTER_Z),
    'RotorFan': (-0.145, 0, CENTER_Z),
    'ShaftKey': (0.269, 0, CENTER_Z + 0.023),
    'Shaft': (0, 0, CENTER_Z),
    'RotorCage': (0, 0, CENTER_Z),
    'RotorCore': (0, 0, CENTER_Z),
    'StatorCore': (0, 0, CENTER_Z),
    'StatorWinding': (0, 0, CENTER_Z),
    'StatorFrame': (0, 0, CENTER_Z),
    'TerminalBox': (0.035, 0, 0.2925),
    'TerminalLid': (0.035, 0, 0.332),
    'LiftingEye': (-0.090, 0, 0.260),
    'Nameplate': (0.030, -0.136, 0.152),
    'FrontEndShield': (0.190, 0, CENTER_Z),
    'FrontBearing': (0.190, 0, CENTER_Z),
    'FrontBearingCover': (0.229, 0, CENTER_Z),
    'ShaftSeal': (0.222, 0, CENTER_Z),
    'WaveSpring': (-0.164, 0, CENTER_Z),
}
for _id, (obj, _off) in PARTS.items():
    obj.location = PIVOTS[obj.name]

# ---------------------------------------------------------------------------
# Animation
# ---------------------------------------------------------------------------
print('=== Animating ===')
SCENE.frame_set(1)
ROOT.location = (0, 0, 0)
ROOT.keyframe_insert('location', frame=1)
ROOT.location = (0, 0, 0)
ROOT.keyframe_insert('location', frame=30)
ROOT.location = (0, 0, 0.28)
ROOT.keyframe_insert('location', frame=118)
ROOT.location = (0, 0, 0.28)
ROOT.keyframe_insert('location', frame=180)

START_FRAME = 30
END_FRAME = 138
for i, (pid, (obj, offset)) in enumerate(PARTS.items()):
    base = obj.location.copy()
    delay = (i / max(1, len(PARTS) - 1)) * 0.42
    duration = 0.58
    start = int(START_FRAME + delay * (END_FRAME - START_FRAME))
    end = min(165, start + int(duration * (END_FRAME - START_FRAME)))
    obj.location = base
    obj.keyframe_insert('location', frame=1)
    obj.keyframe_insert('location', frame=start)
    obj.location = base + offset
    obj.keyframe_insert('location', frame=end)
    obj.keyframe_insert('location', frame=180)

# Camera animation: assembled close-up, then pull back for the exploded view.
def key_cam(frame, loc, target, lens):
    camera.location = loc
    camera.keyframe_insert('location', frame=frame)
    cam_target.location = target
    cam_target.keyframe_insert('location', frame=frame)
    camera.data.lens = lens
    camera.data.keyframe_insert('lens', frame=frame)

key_cam(1, (1.08, -1.55, 0.68), (0, 0, 0.17), 55)
key_cam(30, (1.03, -1.50, 0.70), (0, 0, 0.18), 55)
key_cam(80, (1.20, -2.15, 0.88), (0, 0, 0.32), 55)
key_cam(128, (1.10, -3.60, 1.00), (0, 0, 0.47), 55)
key_cam(165, (1.00, -3.95, 1.02), (0, 0, 0.50), 55)
key_cam(180, (1.05, -3.85, 1.00), (0, 0, 0.51), 55)

# smooth keyframe interpolation for objects and camera
for obj in [ROOT, camera, cam_target] + [p[0] for p in PARTS.values()]:
    if obj.animation_data and obj.animation_data.action:
        for fcu in obj.animation_data.action.fcurves:
            for kp in fcu.keyframe_points:
                kp.interpolation = 'BEZIER'
                kp.handle_left_type = 'AUTO_CLAMPED'
                kp.handle_right_type = 'AUTO_CLAMPED'

# ---------------------------------------------------------------------------
# Eevee quality / compositor
# ---------------------------------------------------------------------------
SCENE.eevee.taa_render_samples = 64
SCENE.eevee.use_shadows = True
SCENE.eevee.use_soft_shadows = True
try:
    SCENE.eevee.use_raytracing = True
    SCENE.eevee.ray_tracing_options.resolution_scale = '1'
except Exception:
    pass
SCENE.render.image_settings.color_mode = 'RGB'
SCENE.render.resolution_percentage = 100
SCENE.render.use_persistent_data = True

# Subtle glow only; avoid a gamey look.
SCENE.use_nodes = True
tree = SCENE.node_tree
nodes = tree.nodes
links = tree.links
nodes.clear()
rl = nodes.new('CompositorNodeRLayers')
glare = nodes.new('CompositorNodeGlare')
glare.glare_type = 'FOG_GLOW'
glare.quality = 'HIGH'
glare.threshold = 1.2
glare.size = 7
glare.mix = 0.06
comp = nodes.new('CompositorNodeComposite')
links.new(rl.outputs['Image'], glare.inputs['Image'])
links.new(glare.outputs['Image'], comp.inputs['Image'])

# Save the .blend with packed textures and relative paths.
for img in bpy.data.images:
    if not img.packed_file and img.filepath:
        try:
            img.pack()
        except Exception:
            pass
bpy.ops.wm.save_as_mainfile(filepath=OUT_BLEND)
print('SAVED', OUT_BLEND)

# ---------------------------------------------------------------------------
# Render stills
# ---------------------------------------------------------------------------
SCENE.render.resolution_x = 1920
SCENE.render.resolution_y = 1080
SCENE.render.image_settings.file_format = 'PNG'
for frame, path in ((1, os.path.join(RENDERS, 'motor_hero.png')),
                    (165, os.path.join(RENDERS, 'motor_exploded.png'))):
    SCENE.frame_set(frame)
    SCENE.render.filepath = path
    print('RENDER_STILL', frame, path)
    bpy.ops.render.render(write_still=True)

print('DONE')
